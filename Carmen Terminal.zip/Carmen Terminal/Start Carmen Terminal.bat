@echo off
setlocal
cd /d "%~dp0"
set "NODE_EXE="
for /f "delims=" %%N in ('where.exe node 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined NODE_EXE if exist "%LOCALAPPDATA%\Carmen\Runtime\node.exe" set "NODE_EXE=%LOCALAPPDATA%\Carmen\Runtime\node.exe"
if not defined NODE_EXE (
  echo Node.js 18 or newer was not found. Install Node.js or restore "%LOCALAPPDATA%\Carmen\Runtime\node.exe".
  pause
  exit /b 1
)
set "NODE_VERSION="
for /f "delims=" %%V in ('"%NODE_EXE%" --version 2^>nul') do set "NODE_VERSION=%%V"
if not defined NODE_VERSION (
  echo The Node.js runtime could not be started: "%NODE_EXE%"
  pause
  exit /b 1
)
set "NODE_MAJOR=%NODE_VERSION:~1%"
for /f "tokens=1 delims=." %%V in ("%NODE_MAJOR%") do set "NODE_MAJOR=%%V"
if %NODE_MAJOR% LSS 18 (
  echo Node.js 18 or newer is required. Found %NODE_VERSION%.
  pause
  exit /b 1
)
if not exist ".env" copy /y ".env.example" ".env" >nul
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama app.exe" (
  start "" "%LOCALAPPDATA%\Programs\Ollama\ollama app.exe"
  echo Waiting for Ollama...
  for /l %%i in (1,1,30) do (
    curl --silent --fail http://127.0.0.1:11434/api/version >nul 2>&1
    if not errorlevel 1 goto ollama_ready
    "%SystemRoot%\System32\ping.exe" -n 2 -w 1000 127.0.0.1 >nul 2>&1
  )
)
:ollama_ready
"%NODE_EXE%" "%~dp0cli.js"
